1) Go inside makejar folder.(It has all the source file and a MANIFEST.MF file)
2) The main class here is  : MainApplication and it is under package com.company.sometool
   (Change it accordingly : Create a package directory and put all your java files there and find out your main class where main maethod is there)
3) The directory has a MANIFEST.MF file which contains the information of starting java application i.e MainApplication.
3) Compile the code (for this example : javac com\company\sometool\MainApplication.java)
4) Create the Jar (for this example : jar -cvfm app.jar META-INF\MANIFEST.MF com\company\sometool\MainApplication.class)
   (Here we are creating app.jar with MANIFEST.MF file we created earlier)
5) Once jar is created run the jar (for this example : java -jar app.jar)
   