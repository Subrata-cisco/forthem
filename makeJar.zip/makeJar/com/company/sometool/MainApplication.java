package com.company.sometool;
public class MainApplication {
	public static void main(String[] args) {
		System.out.println("****** Running main program from Jar *****");
	}
}
