package com.subrata.jar;

public class MainApplication {
	public MainApplication() {
		
	}
	
	public static void main(String[] args) {
		System.out.println("MainApplication.MainApplication()");
	}

}
