# spark-pika

An example app to teach how to create a Spark application with SBT.

Read the blog post for the full walkthrough.